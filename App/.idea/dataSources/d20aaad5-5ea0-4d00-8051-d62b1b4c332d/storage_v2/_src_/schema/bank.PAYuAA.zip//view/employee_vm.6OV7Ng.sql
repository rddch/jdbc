create definer = ruslan@localhost view employee_vm as
select `bank`.`employee`.`emp_id`           AS `emp_id`,
       `bank`.`employee`.`fname`            AS `fname`,
       `bank`.`employee`.`lname`            AS `lname`,
       year(`bank`.`employee`.`start_date`) AS `start_year`
from `bank`.`employee`;

