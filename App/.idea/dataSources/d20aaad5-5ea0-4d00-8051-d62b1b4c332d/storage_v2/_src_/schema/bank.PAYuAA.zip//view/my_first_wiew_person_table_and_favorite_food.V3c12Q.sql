create definer = ruslan@localhost view my_first_wiew_person_table_and_favorite_food as
select `bank`.`person`.`person_id`   AS `person_id`,
       `bank`.`person`.`fname`       AS `fname`,
       `bank`.`person`.`lname`       AS `lname`,
       `bank`.`person`.`gender`      AS `gender`,
       `bank`.`favorite_food`.`food` AS `food_from_favorite_food`
from (`bank`.`person`
       join `bank`.`favorite_food`);

